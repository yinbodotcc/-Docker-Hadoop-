JAVA_HOME=/usr/local/jdk1.8.0_191
